package com.scope.bean;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainClass {

	public static void main(String[] args) 
	{
		 AnnotationConfigApplicationContext a = new AnnotationConfigApplicationContext("com.scope.bean");
		 Mobile mo=a.getBean(Mobile.class);
		 Mobile mo1=a.getBean(Mobile.class);
		 System.out.println(mo.hashCode()+" "+mo1.hashCode());
		 System.out.println(mo);
		
		 System.out.println("-----------------------");
		 
		 Person p=a.getBean(Person.class);
		 Person p1=a.getBean(Person.class);
		 System.out.println(p.hashCode()+" "+p1.hashCode());
		 System.out.println(p);
		 
		 

	}

}
